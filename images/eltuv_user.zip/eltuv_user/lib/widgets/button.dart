import 'package:flutter/material.dart';

class button extends StatelessWidget {
  final String inputtext;
  final VoidCallback onPressed;

  button({this.inputtext='',required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.05),
      child: Row(
        children: [
          Expanded(
            child: MaterialButton(onPressed: onPressed,
            color: Color(0xffc70039),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding:  EdgeInsets.symmetric(vertical: MediaQuery.of(context).size.height*0.03),
                child: Text(inputtext,style: TextStyle(color: Colors.white,fontFamily: 'Raleway',),),
              ),

            ),
          ),
        ],
      ),
    );
  }
}
