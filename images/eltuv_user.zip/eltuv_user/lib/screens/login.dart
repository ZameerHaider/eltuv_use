import 'package:eltuv_user/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  bool _isObscurepassword = true;
  String initialCountry = 'US';
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: size.height*0.12),
            Image.asset('images/logo.png',scale: MediaQuery.of(context).size.height*0.002,),
            Text('Eltuv',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',
                fontSize: MediaQuery.of(context).size.height*0.07),),
            SizedBox(height: size.height*0.05),
            Text('Login',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',fontSize: MediaQuery.of(context).size.height*0.04),),
            SizedBox(height: size.height*0.05),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.black87 ,
                          width: 1.0 ,
                        ),
                        borderRadius: BorderRadius.circular(20)
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: ImageIcon(AssetImage('images/mbl.png',),size: 10,),
                    ),
                  ),
                  SizedBox(width: size.width*0.01,),
                  Text('Mobile Number',style: TextStyle(color: Colors.grey,fontFamily: 'Raleway'),)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: InternationalPhoneNumberInput(onInputChanged: (PhoneNumber number){
                print(number.phoneNumber);
              },
                onInputValidated: (bool value) {
                  print(value);
                },
                cursorColor: Colors.black,
                inputDecoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)
                    )
                ),
                ignoreBlank: true,
                autoValidateMode: AutovalidateMode.disabled,
                selectorConfig: SelectorConfig(
                  setSelectorButtonAsPrefixIcon: true,
                  selectorType: PhoneInputSelectorType.DROPDOWN,
                ),
              ),
            ),
            SizedBox(height: size.height*0.04),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: Row(
                children: [
                  Icon(Icons.lock_outline_rounded),
                  SizedBox(width: size.width*0.01,),
                  Text('Password',style: TextStyle(color: Colors.grey,fontFamily: 'Raleway'),)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: TextField(
                obscureText: _isObscurepassword,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)
                    ),
                    suffix: GestureDetector(
                      onTap: (){
                        setState(() {
                          _isObscurepassword = !_isObscurepassword;
                        });
                      },
                      child: Text(_isObscurepassword ? "Show" :"Hide",style: TextStyle(color: Color(0xff4D6D00)),),
                    )
                ),
              ),
            ),
            SizedBox(height: size.height*0.05),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal:size.height*0.02),
              child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text('Forgot\npassword?',style: TextStyle(color: Color(0xffc70039),fontFamily: 'Raleway',fontWeight: FontWeight.bold,fontSize: size.height*0.02),)),
            ),
            SizedBox(height: size.height*0.07),
            button(onPressed: (){
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(builder: (context) => personalinfo())
              // );

            },
              inputtext: 'Next',)


          ],
        ),
      ),
    );
  }
}
