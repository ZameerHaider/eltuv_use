import 'package:eltuv_user/screens/login.dart';
import 'package:eltuv_user/widgets/button.dart';
import 'package:flutter/material.dart';

class setpassword extends StatefulWidget {
  const setpassword({Key? key}) : super(key: key);

  @override
  _setpasswordState createState() => _setpasswordState();
}

class _setpasswordState extends State<setpassword> {
  bool _isObscurepassword = true;
  bool _isObscureretypepassword = true;
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: size.height*0.15),
            Text('Set Password',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',  fontSize: MediaQuery.of(context).size.height*0.04),),
            SizedBox(height: size.height*0.15,),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: Row(
                children: [
                  Icon(Icons.lock_outline_rounded),
                  SizedBox(width: size.width*0.01,),
                  Text('Password',style: TextStyle(fontFamily: 'Raleway'),)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: TextField(
                obscureText: _isObscurepassword,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)
                    ),
                    suffix: GestureDetector(
                      onTap: (){
                        setState(() {
                          _isObscurepassword = !_isObscurepassword;
                        });
                      },
                      child: Text(_isObscurepassword ? "Show" :"Hide",style: TextStyle(color: Color(0xff4D6D00)),),
                    )
                ),
              ),
            ),
            SizedBox(height: size.height*0.04,),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: Row(
                children: [
                  Icon(Icons.lock_outline_rounded),
                  SizedBox(width: size.width*0.01,),
                  Text('Retype Password',style: TextStyle(fontFamily: 'Raleway'),)
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.04),
              child: TextField(
                obscureText: _isObscureretypepassword,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)
                    ),
                    suffix: GestureDetector(
                      onTap: (){
                        setState(() {
                          _isObscureretypepassword = !_isObscureretypepassword;
                        });
                      },
                      child: Text(_isObscureretypepassword ? "Show" :"Hide",style: TextStyle(color: Color(0xff4D6D00)),),
                    )
                ),
              ),
            ),
            SizedBox(height: size.height*0.15,),
            button(onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => login()),
              );


            },
              inputtext: 'Next',)
          ],
        ),
      ),
    );
  }
}
