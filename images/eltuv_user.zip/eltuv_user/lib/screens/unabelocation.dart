import 'package:eltuv_user/screens/signup.dart';
import 'package:eltuv_user/widgets/button.dart';
import 'package:flutter/material.dart';

class unabelocation extends StatefulWidget {
  const unabelocation({Key? key}) : super(key: key);

  @override
  _unabelocationState createState() => _unabelocationState();
}

class _unabelocationState extends State<unabelocation> {
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: size.height*0.15),
            Image.asset('images/location.png',scale: MediaQuery.of(context).size.height*0.003,),
            SizedBox(height:size.height*0.04 ,),
            Text('Enable Your Location',style: TextStyle(color: Color(0xffc70039),fontFamily:'Raleway',
                fontWeight: FontWeight.bold,fontSize: MediaQuery.of(context).size.height*0.04),),
            SizedBox(height:size.height*0.03 ,),
            Text('Choose your location to start find the \nrequest around you.',textAlign: TextAlign.center,style: TextStyle(fontFamily: 'Raleway'),),
            SizedBox(height:size.height*0.2 ,),
            button(onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => signup()),
              );

            },
              inputtext: 'USE MY LOCATION',),
            SizedBox(height:size.height*0.03,),
            Text('Skip for now',style: TextStyle(color: Colors.grey,fontFamily: 'Raleway'),)


          ],
        ),
      ),
    );
  }
}
