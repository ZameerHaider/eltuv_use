import 'package:eltuv_user/screens/setpassword.dart';
import 'package:eltuv_user/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class phoneverfication extends StatefulWidget {
  const phoneverfication({Key? key}) : super(key: key);

  @override
  _phoneverficationState createState() => _phoneverficationState();
}

class _phoneverficationState extends State<phoneverfication> {
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[50],
        elevation: 0,
        iconTheme: IconThemeData(color: Color(0xffc70039)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: size.height*0.20),
            Text('Phone Verification',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',fontSize: MediaQuery.of(context).size.height*0.04),),
            SizedBox(height: size.height*0.03),
            Text('Enter your OTP code here',style: TextStyle(fontFamily: 'Raleway'),),
            SizedBox(height: size.height*0.15),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width*0.1),
              child: PinCodeTextField(
                appContext: context,
                length: 4,
                keyboardType: TextInputType.number,
                cursorColor: Colors.black,


                pinTheme: PinTheme(

                  activeColor: Colors.black,
                  inactiveColor: Colors.black,
                  selectedColor: Colors.black,
                ),
                onChanged: (value) {
                  print(value);
                },
              ),
            ),
            SizedBox(height: size.height*0.05),
            button(onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => setpassword()),
              );
            },
              inputtext: 'Verify Now',)



          ],
        ),
      ),

    );
  }
}
