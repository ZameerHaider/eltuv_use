import 'package:eltuv_user/screens/phoneverfication.dart';
import 'package:eltuv_user/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class signup extends StatefulWidget {
  const signup({Key? key}) : super(key: key);

  @override
  _signupState createState() => _signupState();
}

class _signupState extends State<signup> {
  String initialCountry = 'PK';
  final TextEditingController controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: size.height*0.11),
            Image.asset('images/logo.png',scale: MediaQuery.of(context).size.height*0.002,),
            Text('Eltuv',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',
                fontSize: MediaQuery.of(context).size.height*0.07),),
            SizedBox(height: size.height*0.05),
            Text('Sign Up',style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Raleway',fontSize: MediaQuery.of(context).size.height*0.04),),
            SizedBox(height: size.height*0.08),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.06),
              child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Row(
                    children: [
                      ImageIcon(AssetImage('images/mbl.png',),color: Colors.grey,),
                      SizedBox(width: size.width*0.01),
                      Text('Mobile Number',style: TextStyle(color: Colors.grey,fontFamily: 'Raleway'),),
                    ],
                  )),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.06),
              child: InternationalPhoneNumberInput(
                textFieldController: controller,
                onInputChanged: (PhoneNumber number) {
                  print(number.phoneNumber);
                },
                onInputValidated: (bool value) {
                  print(value);
                },
                cursorColor: Colors.black,
                inputDecoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)
                    )
                ),
                ignoreBlank: false,
                selectorConfig: SelectorConfig(
                  setSelectorButtonAsPrefixIcon: true,
                  selectorType: PhoneInputSelectorType.DROPDOWN,
                ),
              ),
            ),
            SizedBox(height: size.height*0.15),
            button(onPressed: (){

              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => phoneverfication()),
              );
            },
              inputtext: 'Sign Up',),
            SizedBox(height: size.height*0.12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Alraeady have an account?',style: TextStyle(fontFamily: 'Raleway'),),
                Text('Sign in',style: TextStyle(color: Color(0xffc70039),fontFamily: 'Raleway',fontWeight: FontWeight.bold,fontSize: 15),)
              ],
            )


          ],
        ),
      ),
    );
  }
}
